/* GIMP - The GNU Image Manipulation Program
 * Copyright (C) 1995 Spencer Kimball and Peter Mattis
 *
 * gimp-contexts.h
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __GIMP_CONTEXTS_H__
#define __GIMP_CONTEXTS_H__


void       gimp_contexts_init  (Gimp    *gimp);
void       gimp_contexts_exit  (Gimp    *gimp);

gboolean   gimp_contexts_load  (Gimp    *gimp,
                                GError **error);
gboolean   gimp_contexts_save  (Gimp    *gimp,
                                GError **error);

gboolean   gimp_contexts_clear (Gimp    *gimp,
                                GError **error);


#endif  /*  __GIMP_CONTEXTS_H__  */
